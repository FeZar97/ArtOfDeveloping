#pragma once
#include "responses.h"

class BusManager {
    BusesStopsMap busesToStop;
    BusesStopsMap stopsToBus;

public:
    void AddBus(const string& bus, const vector<string>& stops);

    BusesForStopResponse GetBusesForStop(const string& stop) const;

    StopsForBusResponse GetStopsForBus(const string& bus) const;

    AllBusesResponse GetAllBuses() const;
};